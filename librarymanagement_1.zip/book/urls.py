from django.urls import path

urlpatterns = [
    # Silence for now
]

