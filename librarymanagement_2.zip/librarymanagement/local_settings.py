from .base_settings import *



# SECURITY WARNING: keep the secret key used in production secret!
SECRET_KEY = 'django-insecure-9)p&+!(*7^ys%r##3ya2)b36@bo2-qax^o+0iids21^y0xp+)n'

# SECURITY WARNING: don't run with debug turned on in production!
DEBUG = True

ALLOWED_HOSTS = []
